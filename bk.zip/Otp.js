import React, { useState } from "react";
import axios from 'axios';

const Otp = () => {
    const storedEmail = localStorage.getItem('email');
    const [email, setEmail] = useState(storedEmail || '');
    const [otp, setOtp] = useState("");

    const handleGetNewOTP = (e) => {
        e.preventDefault();
        axios.post('https://dev-lokichat-api.renesistechdemo.com/api/auth/request-otp', {
            email: email
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                console.log('OTP sent to your email address.', response.data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    const handleVerifyOTP = (e) => {
        setOtp(e.target.value);
    };

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handleSubmitOtp = (e) => {
        e.preventDefault();
        console.log("OTP submitted:", otp);

        axios.post('https://dev-lokichat-api.renesistechdemo.com/api/auth/verify-otp', {
            email: email,
            otp: otp
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                console.log('OTP verified', response.data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    };

    return (
        <div className="container">
            <div className="row justify-content-center mt-5">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-body">
                            <h2 className="text-center mb-4">Enter OTP</h2>
                            <form onSubmit={handleSubmitOtp}>
                                <div className="form-group">
                                    <input type="text" className="form-control" placeholder="Enter OTP" value={otp} onChange={handleVerifyOTP} />
                                </div>
                                <div className="d-flex justify-content-between">
                                    <button type="submit" className="btn btn-primary btn-block my-3">Submit</button>
                                    <button type="button" className="btn btn-primary btn-block my-3" onClick={handleGetNewOTP}>Get new OTP</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Otp;
